# ionic4-template (Steps to Run)
* git init
* git clone https://github.com/thesheikhwasim/ionic4-template.git
* cd ionic4-template
* npm install
* ionic serve
- Hurray! You have successfully taken the template.
