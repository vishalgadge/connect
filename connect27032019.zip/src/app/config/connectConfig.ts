export var LOADING = "Loading";
export var LOADING_MSG = "Please Wait";
